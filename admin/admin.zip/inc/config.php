<?php
$con=mysqli_connect('localhost','root','') or die('error while connecting to Database');
mysqli_select_db($con,'shortnews') or die('Database not found');
?>