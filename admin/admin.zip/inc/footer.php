<!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner"> <?php echo date('Y');?>- All rights reserved<br>Developed by: Sudhanshu Mishra
			
            <a href="#" target="_top" class="makerCss">&copy; News Admin Panel</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->